function rgbim = RGB2RGB(im)

rgbim = im;